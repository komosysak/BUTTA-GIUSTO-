export type Destination = 'yellow' | 'red' | 'blue' | 'brown' | 'verde' | 'vetro' | 'grey';
export type ImageStatus = 'approved' | 'review' | 'missing';

export interface ImageInfo {
  url: string;
  thumbnailUrl?: string;
  source: string;
  sourceUrl?: string;
  author?: string;
  license?: string;
  licenseUrl?: string;
  confidence?: number;
  status: ImageStatus;
  width?: number;
  height?: number;
  title?: string;
}

export interface WasteItem {
  id: string;
  name: string;
  originalName?: string;
  destination: Destination;
  destinationLabel: string;
  description: string;
  aliases: string[];
  keywords: string[];
  category: string;
  municipality: string;
}

export interface MunicipalityConfig {
  id: string;
  name: string;
  destinations: Record<Destination, {
    label: string;
    color: string;
    icon: string;
  }>;
}

export interface SearchResult {
  item: WasteItem;
  score: number;
  matchType: 'exact-name' | 'exact-alias' | 'starts-with' | 'token-match' | 'fuzzy' | 'keyword';
}

export interface AccessibilitySettings {
  textSize: 'normal' | 'large' | 'x-large';
  highContrast: boolean;
  reducedMotion: boolean;
  focusHighlight: boolean;
}

export type ThemeMode = 'light' | 'dark' | 'system';

export interface AppSettings {
  theme: ThemeMode;
  accessibility: AccessibilitySettings;
  municipality: string;
}
