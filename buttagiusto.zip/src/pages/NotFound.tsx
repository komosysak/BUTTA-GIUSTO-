import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import './NotFound.css';

export function NotFound() {
  return (
    <main id="main-content" className="not-found">
      <div className="container">
        <div className="not-found__inner">
          <h1 className="not-found__code">404</h1>
          <h2 className="not-found__title">Pagina non trovata</h2>
          <p className="not-found__desc">
            La pagina che stai cercando non esiste o è stata spostata.
          </p>
          <Link to="/" className="not-found__btn">
            <Home size={18} aria-hidden="true" />
            Torna alla home
          </Link>
        </div>
      </div>
    </main>
  );
}
