import { Link } from 'react-router-dom';
import { Search, ArrowRight, Circle } from 'lucide-react';
import './Guida.css';

export function Guida() {
  return (
    <main id="main-content" className="guida">
      <div className="container container-narrow">
        <h1 className="guida__title">Come usare {import.meta.env.VITE_PROJECT_NAME || 'ButtaGiusto'}</h1>
        <p className="guida__intro">
          Non serve essere esperti di tecnologia. Segui questi semplici passaggi.
        </p>

        <div className="guida__steps">
          <div className="guida-step">
            <div className="guida-step__num" aria-hidden="true">1</div>
            <div className="guida-step__content">
              <h2 className="guida-step__title">Apri "Rifiuti"</h2>
              <p className="guida-step__desc">
                Clicca sul pulsante <strong>Rifiuti</strong> nel menu in alto.
              </p>
            </div>
          </div>

          <div className="guida-step">
            <div className="guida-step__num" aria-hidden="true">2</div>
            <div className="guida-step__content">
              <h2 className="guida-step__title">Cerca quello che vuoi buttare</h2>
              <p className="guida-step__desc">
                Nella barra di ricerca scrivi il nome dell'oggetto.
                Ad esempio: <strong>PENNA</strong>, <strong>BOTTIGLIA</strong>, <strong>LATTINA</strong>.
              </p>
              <div className="guida-step__example">
                <Search size={16} aria-hidden="true" />
                <code>Cerca: penna</code>
              </div>
            </div>
          </div>

          <div className="guida-step">
            <div className="guida-step__num" aria-hidden="true">3</div>
            <div className="guida-step__content">
              <h2 className="guida-step__title">Seleziona l'oggetto</h2>
              <p className="guida-step__desc">
                Dal catalogo, clicca sull'oggetto che corrisponde a quello che hai in mano.
              </p>
            </div>
          </div>

          <div className="guida-step">
            <div className="guida-step__num" aria-hidden="true">4</div>
            <div className="guida-step__content">
              <h2 className="guida-step__title">Leggi in quale sacco va</h2>
              <p className="guida-step__desc">
                Verrà mostrato chiaramente se l'oggetto va nel sacco rosso o nel sacco giallo.
              </p>
            </div>
          </div>
        </div>

        <section className="guida-example" aria-labelledby="example-title">
          <h2 id="example-title" className="guida-example__title">Esempio pratico</h2>
          <div className="guida-example__card">
            <p className="guida-example__q">Hai una penna scarica?</p>
            <div className="guida-example__search">
              <Search size={16} aria-hidden="true" />
              <span>Cerca: <strong>PENNA</strong></span>
            </div>
            <div className="guida-example__arrow" aria-hidden="true">
              <ArrowRight size={24} />
            </div>
            <div className="guida-example__result">
              <span className="guida-example__item">Penne biro</span>
              <div className="guida-example__dest">
                <Circle size={14} fill="currentColor" aria-hidden="true" />
                <span>SACCO ROSSO</span>
              </div>
            </div>
          </div>
        </section>

        <section className="guida-tips" aria-labelledby="tips-title">
          <h2 id="tips-title" className="guida-example__title">Consigli utili</h2>
          <ul className="guida-tips__list">
            <li>Non serve scrivere in modo perfetto. Il sistema capisce anche "penn" o "bottiglia plastica".</li>
            <li>Se non trovi un oggetto, prova con un nome diverso o più semplice.</li>
            <li>Puoi usare la ricerca vocale premendo il microfono nella barra di ricerca.</li>
            <li>Le impostazioni di accessibilità sono disponibili dal menu in alto.</li>
          </ul>
        </section>

        <div className="guida__cta">
          <Link to="/rifiuti" className="hero__btn hero__btn--primary">
            Inizia ora
            <ArrowRight size={18} aria-hidden="true" />
          </Link>
        </div>
      </div>
    </main>
  );
}
