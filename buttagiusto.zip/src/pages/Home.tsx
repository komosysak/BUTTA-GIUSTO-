import { Link } from 'react-router-dom';
import { ArrowRight, Leaf, Search, BookOpen, Circle } from 'lucide-react';
import { brand } from '../config/brand';
import { useSearch } from '../hooks/useSearch';
import './Home.css';

const categories = [
  { key: 'yellow', label: 'Multipak', desc: 'Plastica, alluminio, lattine, Tetra Pak', colorClass: 'yellow' },
  { key: 'red', label: 'Ecuosacco', desc: 'Secco residuo, non riciclabili', colorClass: 'red' },
  { key: 'blue', label: 'Carta', desc: 'Carta, cartone, giornali, riviste', colorClass: 'blue' },
  { key: 'brown', label: 'Umido', desc: 'Cibo, avanzi, fondi caffè', colorClass: 'brown' },
  { key: 'verde', label: 'Verde', desc: 'Scarti vegetali, erba, foglie', colorClass: 'verde' },
  { key: 'vetro', label: 'Vetro', desc: 'Bottiglie, barattoli, vasetti di vetro', colorClass: 'vetro' },
  { key: 'grey', label: 'Piattaforma', desc: 'Elettrodomestici, ingombranti, RAEE', colorClass: 'grey' },
];

export function Home() {
  const { popularItems } = useSearch();

  return (
    <main id="main-content">
      <section className="hero" aria-labelledby="hero-title">
        <div className="container hero__inner">
          <div className="hero__content">
            <span className="hero__label">Servizio di classificazione rifiuti</span>
            <h1 id="hero-title" className="hero__title">
              Scopri dove buttare
              <br />
              <span className="hero__title-accent">ogni rifiuto</span>
            </h1>
            <p className="hero__desc">
              Non devi sapere come funziona la raccolta differenziata.
              Devi soltanto sapere che cosa hai in mano.
            </p>
            <div className="hero__actions">
              <Link to="/rifiuti" className="hero__btn hero__btn--primary">
                Cerca un rifiuto
                <ArrowRight size={18} aria-hidden="true" />
              </Link>
              <Link to="/guida" className="hero__btn hero__btn--secondary">
                Come funziona
              </Link>
            </div>
          </div>
          <div className="hero__visual" aria-hidden="true">
            <div className="hero__card hero__card--yellow">
              <Circle size={32} fill="currentColor" />
              <span>Multipak</span>
            </div>
            <div className="hero__card hero__card--red">
              <Circle size={32} fill="currentColor" />
              <span>Ecuosacco</span>
            </div>
          </div>
        </div>
      </section>

      <section className="how-it-works" aria-labelledby="how-title">
        <div className="container">
          <h2 id="how-title" className="section-title">Come funziona</h2>
          <div className="steps">
            <div className="step">
              <div className="step__icon">
                <Search size={24} aria-hidden="true" />
              </div>
              <h3 className="step__title">1. Cerca</h3>
              <p className="step__desc">Scrivi il nome dell'oggetto che vuoi buttare.</p>
            </div>
            <div className="step">
              <div className="step__icon">
                <BookOpen size={24} aria-hidden="true" />
              </div>
              <h3 className="step__title">2. Seleziona</h3>
              <p className="step__desc">Trova l'oggetto giusto tra i risultati.</p>
            </div>
            <div className="step">
              <div className="step__icon">
                <Leaf size={24} aria-hidden="true" />
              </div>
              <h3 className="step__title">3. Conferisci</h3>
              <p className="step__desc">Leggi in quale sacco o contenitore deve andare.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="destinations" aria-labelledby="dest-title">
        <div className="container">
          <h2 id="dest-title" className="section-title">Le 7 categorie di raccolta</h2>
          <div className="dest-cards">
            {categories.map(cat => (
              <div key={cat.key} className={`dest-card dest-card--${cat.colorClass}`}>
                <div className="dest-card__badge">
                  <Circle size={20} fill="currentColor" aria-hidden="true" />
                  <span>{cat.label}</span>
                </div>
                <p className="dest-card__desc">{cat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="popular" aria-labelledby="popular-title">
        <div className="container">
          <h2 id="popular-title" className="section-title">Alcuni rifiuti popolari</h2>
          <div className="popular__grid">
            {popularItems.map(item => (
              <Link key={item.id} to="/rifiuti" className="popular__link">
                <div className={`popular__dot popular__dot--${item.destination}`} aria-hidden="true" />
                <span>{item.name}</span>
              </Link>
            ))}
          </div>
          <div className="popular__cta">
            <Link to="/rifiuti" className="hero__btn hero__btn--primary">
              Vedi tutti i rifiuti
              <ArrowRight size={18} aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      <section className="about" aria-labelledby="about-title">
        <div className="container container-narrow">
          <h2 id="about-title" className="section-title">Il progetto</h2>
          <div className="about__content">
            <p>
              <strong>{brand.shortName}</strong> è un progetto open source che mira a semplificare
              la vita di chi vuole smaltire correttamente i propri rifiuti.
            </p>
            <p>
              Il funzionamento è completamente deterministico: il sistema utilizza un dataset
              predefinito e non si avvale di intelligenza artificiale per classificare gli oggetti.
            </p>
            <p>
              Il codice sorgente è disponibile su GitHub. Chiunque può contribuire,
              segnalare problemi o proporre miglioramenti.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
