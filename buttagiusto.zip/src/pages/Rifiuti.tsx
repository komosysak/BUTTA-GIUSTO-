import { useState, useCallback } from 'react';
import type { WasteItem } from '../types';
import { useSearch } from '../hooks/useSearch';
import { useVoiceSearch } from '../hooks/useVoiceSearch';
import { SearchBar } from '../components/SearchBar';
import { FilterBar } from '../components/FilterBar';
import { WasteCard } from '../components/WasteCard';
import { WasteDetail } from '../components/WasteDetail';
import './Rifiuti.css';

export function Rifiuti() {
  const {
    query,
    setQuery,
    filter,
    setFilter,
    results,
    allItems,
    totalCount,
    clearSearch,
  } = useSearch();

  const [selectedItem, setSelectedItem] = useState<WasteItem | null>(null);

  const handleVoiceResult = useCallback((text: string) => {
    setQuery(text);
  }, [setQuery]);

  const { isSupported: voiceSupported, isListening: voiceListening, startListening, stopListening } = useVoiceSearch(handleVoiceResult);

  const handleCardClick = useCallback((item: WasteItem) => {
    setSelectedItem(item);
  }, []);

  const handleCloseDetail = useCallback(() => {
    setSelectedItem(null);
  }, []);

  const displayItems = query.trim() ? results.map(r => r.item) : allItems;

  return (
    <main id="main-content" className="rifiuti">
      <div className="container">
        <SearchBar
          query={query}
          onQueryChange={setQuery}
          onClear={clearSearch}
          resultCount={results.length}
          totalCount={totalCount}
          voiceSupported={voiceSupported}
          voiceListening={voiceListening}
          onVoiceStart={startListening}
          onVoiceStop={stopListening}
        />

        <FilterBar filter={filter} onFilterChange={setFilter} />

        <div className="rifiuti__grid" role="list" aria-label="Catalogo rifiuti">
          {displayItems.length > 0 ? (
            displayItems.map(item => (
              <div key={item.id} role="listitem">
                <WasteCard item={item} onClick={handleCardClick} />
              </div>
            ))
          ) : (
            <div className="rifiuti__empty" role="status">
              <p className="rifiuti__empty-text">
                {query
                  ? 'Nessun risultato trovato. Prova con un altro termine.'
                  : 'Nessun elemento disponibile.'}
              </p>
            </div>
          )}
        </div>

        <WasteDetail item={selectedItem} onClose={handleCloseDetail} />
      </div>
    </main>
  );
}
