import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useState, useCallback } from 'react';
import { Settings } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { KomosysFooter } from './components/KomosysFooter';
import { AccessibilityPanel } from './components/AccessibilityPanel';
import { Home } from './pages/Home';
import { Guida } from './pages/Guida';
import { Rifiuti } from './pages/Rifiuti';
import { NotFound } from './pages/NotFound';
import { useTheme } from './hooks/useTheme';
import { useAccessibility } from './hooks/useAccessibility';
import './styles/global.css';

function App() {
  const { theme, setTheme } = useTheme();
  const { settings, updateSetting, resetSettings } = useAccessibility();
  const [a11yOpen, setA11yOpen] = useState(false);

  const toggleA11y = useCallback(() => setA11yOpen(prev => !prev), []);

  return (
    <BrowserRouter>
      <a href="#main-content" className="skip-link">
        Vai al contenuto principale
      </a>

      <svg style={{ position: 'absolute', width: 0, height: 0 }} aria-hidden="true">
        <defs>
          <filter id="komosys-warp">
            <feTurbulence type="fractalNoise" baseFrequency="0.015" numOctaves="2" result="noise" seed="1" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="3" xChannelSelector="R" yChannelSelector="G" />
          </filter>
          <filter id="komosys-warp-active">
            <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="3" result="noise" seed="2" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="8" xChannelSelector="R" yChannelSelector="G" />
          </filter>
        </defs>
      </svg>

      <Navbar />

      <button
        className="a11y-fab"
        onClick={toggleA11y}
        aria-label="Apri pannello accessibilità"
        type="button"
      >
        <Settings size={20} />
      </button>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/guida" element={<Guida />} />
        <Route path="/rifiuti" element={<Rifiuti />} />
        <Route path="*" element={<NotFound />} />
      </Routes>

      <Footer />
      <KomosysFooter />

      <AccessibilityPanel
        isOpen={a11yOpen}
        onClose={() => setA11yOpen(false)}
        theme={theme}
        onThemeChange={setTheme}
        settings={settings}
        onSettingChange={updateSetting}
        onReset={resetSettings}
      />
    </BrowserRouter>
  );
}

export default App;
