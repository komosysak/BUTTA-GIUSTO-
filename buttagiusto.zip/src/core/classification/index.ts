import type { WasteItem, SearchResult } from '../../types';

export interface ClassificationResult {
  found: boolean;
  primary?: WasteItem;
  alternatives: WasteItem[];
  query: string;
  message?: string;
}

const CONFIDENCE_THRESHOLD = 0.5;

export function classify(results: SearchResult[], query: string): ClassificationResult {
  if (results.length === 0) {
    return {
      found: false,
      alternatives: [],
      query,
      message: 'Non abbiamo ancora trovato questo oggetto. Prova con un altro nome.',
    };
  }

  const top = results[0];

  if (top.score < CONFIDENCE_THRESHOLD && results.length > 1) {
    const alternatives = results.slice(0, 4).map(r => r.item);
    return {
      found: false,
      alternatives,
      query,
      message: 'Non siamo sicuri di aver trovato l\'oggetto giusto. Seleziona dall\'elenco:',
    };
  }

  if (top.score < CONFIDENCE_THRESHOLD) {
    return {
      found: false,
      alternatives: [top.item],
      query,
      message: 'Non siamo sicuri di aver trovato l\'oggetto giusto. È questo che cercavi?',
    };
  }

  const sameNameItems = results.filter(r => r.item.id !== top.item.id && r.score > 0.8);

  if (sameNameItems.length > 0) {
    const topDest = top.item.destination;
    const conflicts = sameNameItems.filter(r => r.item.destination !== topDest);
    if (conflicts.length > 0) {
      return {
        found: true,
        primary: top.item,
        alternatives: sameNameItems.map(r => r.item),
        query,
      };
    }
  }

  return {
    found: true,
    primary: top.item,
    alternatives: sameNameItems.length > 0 ? sameNameItems.map(r => r.item) : [],
    query,
  };
}
