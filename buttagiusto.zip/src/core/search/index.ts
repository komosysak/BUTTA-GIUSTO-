import Fuse from 'fuse.js';
import type { WasteItem, SearchResult } from '../../types';
import { normalizeText } from '../normalization';

const fuse = new Fuse([] as WasteItem[], {
  keys: [
    { name: 'name', weight: 0.4 },
    { name: 'aliases', weight: 0.35 },
    { name: 'keywords', weight: 0.15 },
    { name: 'description', weight: 0.1 },
  ],
  threshold: 0.2,
  includeScore: true,
  minMatchCharLength: 2,
  ignoreLocation: true,
});

let indexedItems: WasteItem[] = [];

export function initSearch(items: WasteItem[]): void {
  indexedItems = items;
  fuse.setCollection(items);
}

export function search(query: string): SearchResult[] {
  const normalized = normalizeText(query);
  if (!normalized || normalized.length < 1) return [];

  const results: SearchResult[] = [];
  const seen = new Set<string>();

  for (const item of indexedItems) {
    const nName = normalizeText(item.name);
    if (nName === normalized) {
      results.push({ item, score: 1.0, matchType: 'exact-name' });
      seen.add(item.id);
    }
  }

  for (const item of indexedItems) {
    if (seen.has(item.id)) continue;
    for (const alias of item.aliases) {
      if (normalizeText(alias) === normalized) {
        results.push({ item, score: 0.95, matchType: 'exact-alias' });
        seen.add(item.id);
        break;
      }
    }
  }

  for (const item of indexedItems) {
    if (seen.has(item.id)) continue;
    const nName = normalizeText(item.name);
    if (nName.startsWith(normalized) && nName.length > normalized.length) {
      results.push({ item, score: 0.85, matchType: 'starts-with' });
      seen.add(item.id);
    }
  }

  for (const item of indexedItems) {
    if (seen.has(item.id)) continue;
    const nName = normalizeText(item.name);
    const tokens = normalized.split(' ').filter(t => t.length >= 2);
    const nameTokens = nName.split(' ').filter(t => t.length >= 2);
    const aliasTokens = new Set(
      item.aliases.flatMap(a => normalizeText(a).split(' ')).filter(t => t.length >= 2)
    );
    const queryInName = tokens.every(t => nName.includes(t));
    const queryInAliases = tokens.every(t =>
      item.aliases.some(a => normalizeText(a).includes(t))
    );
    const exactTokenMatch = nameTokens.some(t => tokens.includes(t));
    if (queryInName || queryInAliases) {
      const matchRatio = tokens.filter(t => nName.includes(t) || aliasTokens.has(t)).length / tokens.length;
      results.push({ item, score: 0.7 + matchRatio * 0.15, matchType: 'token-match' });
      seen.add(item.id);
    } else if (exactTokenMatch) {
      results.push({ item, score: 0.55, matchType: 'token-match' });
      seen.add(item.id);
    }
  }

  const fuseResults = fuse.search(normalized);
  for (const fr of fuseResults) {
    if (seen.has(fr.item.id)) continue;
    const fuseScore = 1 - (fr.score ?? 0.5);
    if (fuseScore > 0.6) {
      results.push({ item: fr.item, score: fuseScore * 0.5, matchType: 'fuzzy' });
      seen.add(fr.item.id);
    }
  }

  for (const item of indexedItems) {
    if (seen.has(item.id)) continue;
    const kwMatch = item.keywords.some(k => {
      const nk = normalizeText(k);
      return nk === normalized || nk.startsWith(normalized) || normalized.startsWith(nk);
    });
    if (kwMatch) {
      results.push({ item, score: 0.25, matchType: 'keyword' });
      seen.add(item.id);
    }
  }

  return results.sort((a, b) => b.score - a.score);
}
