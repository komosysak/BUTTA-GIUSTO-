const ITALIAN_ACCENT_MAP: Record<string, string> = {
  'à': 'a', 'è': 'e', 'é': 'e', 'ì': 'i', 'ò': 'o', 'ù': 'u',
  'á': 'a', 'ë': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u',
  'â': 'a', 'ê': 'e', 'î': 'i', 'ô': 'o', 'û': 'u',
};

export function normalizeText(input: string): string {
  let text = input.toLowerCase().trim();
  text = text.replace(/\s+/g, ' ');
  text = text.replace(/['']/g, "'");
  text = text.split('').map(ch => ITALIAN_ACCENT_MAP[ch] || ch).join('');
  return text;
}

export function tokenize(text: string): string[] {
  return normalizeText(text).split(' ').filter(t => t.length > 0);
}
