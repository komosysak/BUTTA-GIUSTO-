import { useState, useCallback, useRef } from 'react';

interface VoiceSearchState {
  isListening: boolean;
  isSupported: boolean;
  transcript: string;
  error: string | null;
}

export function useVoiceSearch(onResult: (text: string) => void) {
  const [state, setState] = useState<VoiceSearchState>({
    isListening: false,
    isSupported: typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window),
    transcript: '',
    error: null,
  });

  const recognitionRef = useRef<any>(null);

  const startListening = useCallback(() => {
    if (!state.isSupported) return;

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'it-IT';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setState(prev => ({ ...prev, isListening: true, error: null }));
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setState(prev => ({ ...prev, transcript, isListening: false }));
        onResult(transcript);
      };

      recognition.onerror = (event: any) => {
        setState(prev => ({
          ...prev,
          isListening: false,
          error: event.error === 'not-allowed'
            ? 'Permesso microfono negato.'
            : 'Ricerca vocale non disponibile.',
        }));
      };

      recognition.onend = () => {
        setState(prev => ({ ...prev, isListening: false }));
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setState(prev => ({ ...prev, error: 'Ricerca vocale non disponibile in questo browser.' }));
    }
  }, [state.isSupported, onResult]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setState(prev => ({ ...prev, isListening: false }));
  }, []);

  return { ...state, startListening, stopListening };
}
