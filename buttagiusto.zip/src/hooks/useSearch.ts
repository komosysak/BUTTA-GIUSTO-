import { useState, useMemo, useCallback, useEffect } from 'react';
import type { WasteItem, SearchResult, Destination } from '../types';
import { initSearch, search } from '../core/search';
import { classify, type ClassificationResult } from '../core/classification';
import items from '../data/waste-items.json';

const wasteItems = items as WasteItem[];

export type FilterType = 'all' | Destination;

export function useSearch() {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');

  useEffect(() => {
    initSearch(wasteItems);
  }, []);

  const results = useMemo<SearchResult[]>(() => {
    if (!query.trim()) return [];
    return search(query.trim());
  }, [query]);

  const filteredResults = useMemo(() => {
    if (filter === 'all') return results;
    return results.filter(r => r.item.destination === filter);
  }, [results, filter]);

  const classification = useMemo<ClassificationResult>(() => {
    return classify(filteredResults.length > 0 ? filteredResults : results, query);
  }, [results, filteredResults, query]);

  const allItems = useMemo(() => {
    if (filter === 'all') return wasteItems;
    return wasteItems.filter(item => item.destination === filter);
  }, [filter]);

  const popularItems = useMemo(() => {
    return wasteItems.filter(item =>
      ['penne-biro', 'bottiglie-plastica', 'carta-stagnola', 'bicchieri-plastica', 'lattine', 'spazzolini-denti'].includes(item.id)
    );
  }, []);

  const clearSearch = useCallback(() => {
    setQuery('');
    setFilter('all');
  }, []);

  return {
    query,
    setQuery,
    filter,
    setFilter,
    results: filteredResults,
    classification,
    allItems,
    popularItems,
    clearSearch,
    totalCount: wasteItems.length,
  };
}
