import { useState, useEffect, useCallback } from 'react';
import type { AccessibilitySettings } from '../types';

const DEFAULT_SETTINGS: AccessibilitySettings = {
  textSize: 'normal',
  highContrast: false,
  reducedMotion: false,
  focusHighlight: false,
};

function loadSettings(): AccessibilitySettings {
  try {
    const saved = localStorage.getItem('buttagiusto-a11y');
    if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
  } catch {}
  return DEFAULT_SETTINGS;
}

function applySettings(settings: AccessibilitySettings) {
  document.documentElement.setAttribute('data-text-size', settings.textSize);
  document.documentElement.setAttribute('data-high-contrast', String(settings.highContrast));
  document.documentElement.setAttribute('data-reduced-motion', String(settings.reducedMotion));
  document.documentElement.setAttribute('data-focus-highlight', String(settings.focusHighlight));
}

export function useAccessibility() {
  const [settings, setSettingsState] = useState<AccessibilitySettings>(loadSettings);

  useEffect(() => {
    applySettings(settings);
    try {
      localStorage.setItem('buttagiusto-a11y', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  const updateSetting = useCallback(<K extends keyof AccessibilitySettings>(
    key: K,
    value: AccessibilitySettings[K]
  ) => {
    setSettingsState(prev => ({ ...prev, [key]: value }));
  }, []);

  const resetSettings = useCallback(() => {
    setSettingsState(DEFAULT_SETTINGS);
  }, []);

  return { settings, updateSetting, resetSettings };
}
