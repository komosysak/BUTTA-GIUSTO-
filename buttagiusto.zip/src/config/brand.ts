export const brand = {
  projectName: 'ButtaGiusto',
  shortName: 'ButtaGiusto',
  companyName: 'KOMOSYS Dev',
  tagline: 'Scopri dove buttare i tuoi rifiuti',
  description: 'Il servizio gratuito che ti dice esattamente in quale sacco conferire ogni oggetto.',
  logo: '/logo.svg',
  githubUrl: 'https://github.com/komosysak/BUTTA-GIUSTO-',
  paypalUrl: '',
  portfolioUrl: 'https://komosys.dev',
  year: new Date().getFullYear(),
} as const;
