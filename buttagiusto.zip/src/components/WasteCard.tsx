import type { WasteItem } from '../types';
import { WasteIcon } from './WasteIcon';
import './WasteCard.css';

interface WasteCardProps {
  item: WasteItem;
  onClick: (item: WasteItem) => void;
}

const DEST_LABELS: Record<string, string> = {
  yellow: 'Multipak',
  red: 'Ecuosacco',
  blue: 'Carta',
  brown: 'Umido',
  verde: 'Verde',
  vetro: 'Vetro',
  grey: 'Piattaforma',
};

export function WasteCard({ item, onClick }: WasteCardProps) {
  return (
    <button
      className={`waste-card waste-card--${item.destination}`}
      onClick={() => onClick(item)}
      aria-label={`${item.name} — ${item.destinationLabel}`}
      type="button"
    >
      <div className={`waste-card__visual waste-card__visual--${item.destination}`} aria-hidden="true">
        <WasteIcon item={item} size={34} />
      </div>
      <div className="waste-card__content">
        <span className="waste-card__name">{item.name}</span>
        <span className={`waste-card__badge waste-card__badge--${item.destination}`}>
          {DEST_LABELS[item.destination] || item.destination}
        </span>
      </div>
    </button>
  );
}