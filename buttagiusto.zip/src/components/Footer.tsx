import { Leaf } from 'lucide-react';
import { brand } from '../config/brand';
import './Footer.css';

export function Footer() {
  return (
    <footer className="footer" role="contentinfo">
      <div className="container">
        <div className="footer__inner">
          <div className="footer__brand">
            <Leaf size={18} aria-hidden="true" />
            <span>{brand.shortName}</span>
          </div>
          <p className="footer__copy">
            Sito web open source creato da{' '}
            <a
              href={brand.portfolioUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              {brand.companyName}
            </a>
          </p>
          <div className="footer__links">
            <a href={brand.githubUrl} target="_blank" rel="noopener noreferrer">
              GitHub
            </a>
            <a href={brand.portfolioUrl} target="_blank" rel="noopener noreferrer">
              Portfolio
            </a>
            {brand.paypalUrl && (
              <a href={brand.paypalUrl} target="_blank" rel="noopener noreferrer">
                Sostieni
              </a>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
