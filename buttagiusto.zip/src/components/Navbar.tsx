import { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Leaf, Home as HomeIcon, BookOpen, Recycle } from 'lucide-react';
import { brand } from '../config/brand';
import './Navbar.css';

const NAV_LINKS = [
  { to: '/', label: 'Home', icon: HomeIcon },
  { to: '/guida', label: 'Guida', icon: BookOpen },
  { to: '/rifiuti', label: 'Rifiuti', icon: Recycle, primary: true },
];

export function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const toggleRef = useRef<HTMLButtonElement>(null);
  const sheetRef = useRef<HTMLDivElement>(null);

  // Close the menu whenever the route changes (navigation always wins).
  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  // Lock body scroll while the sheet is open.
  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  // Close on Escape.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [menuOpen]);

  // Move focus into the sheet once it is on screen.
  useEffect(() => {
    if (!menuOpen) return;
    const t = window.setTimeout(() => {
      sheetRef.current?.querySelector<HTMLElement>('a')?.focus();
    }, 60);
    return () => window.clearTimeout(t);
  }, [menuOpen]);

  const closeMenu = useCallback(() => {
    setMenuOpen(false);
    toggleRef.current?.focus();
  }, []);

  return (
    <nav className="navbar" role="navigation" aria-label="Navigazione principale">
      <div className="navbar__inner container">
        <Link to="/" className="navbar__brand" aria-label={`${brand.projectName} - Home`}>
          <Leaf className="navbar__logo-icon" size={24} strokeWidth={2} aria-hidden="true" />
          <span className="navbar__logo-text">{brand.shortName}</span>
        </Link>

        <button
          ref={toggleRef}
          className="navbar__toggle"
          onClick={() => setMenuOpen(o => !o)}
          aria-expanded={menuOpen}
          aria-controls="mobile-nav"
          aria-label={menuOpen ? 'Chiudi menu' : 'Apri menu'}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>

        <div className="navbar__menu" id="desktop-nav" role="menubar">
          {NAV_LINKS.map(link => {
            const active = location.pathname === link.to;
            return (
              <Link
                key={link.to}
                to={link.to}
                className={`navbar__link ${active ? 'navbar__link--active' : ''} ${link.primary ? 'navbar__link--cta' : ''}`}
                role="menuitem"
              >
                {link.label}
              </Link>
            );
          })}
        </div>
      </div>

      {menuOpen && typeof document !== 'undefined' && createPortal(
        <div className="mobile-nav" id="mobile-nav" role="dialog" aria-modal="true" aria-label="Menu di navigazione">
          <button
            className="mobile-nav__scrim"
            onClick={closeMenu}
            tabIndex={-1}
            aria-label="Chiudi menu"
          />
          <div className="mobile-nav__sheet" ref={sheetRef}>
            <div className="mobile-nav__header">
              <span className="mobile-nav__brand">
                <Leaf size={18} aria-hidden="true" />
                {brand.shortName}
              </span>
              <button
                className="mobile-nav__close"
                onClick={closeMenu}
                aria-label="Chiudi menu"
                type="button"
              >
                <X size={20} />
              </button>
            </div>
            <nav className="mobile-nav__links" aria-label="Menu di navigazione">
              {NAV_LINKS.map(link => {
                const Icon = link.icon;
                const active = location.pathname === link.to;
                return (
                  <Link
                    key={link.to}
                    to={link.to}
                    className={`mobile-nav__link ${active ? 'is-active' : ''} ${link.primary ? 'is-primary' : ''}`}
                    aria-current={active ? 'page' : undefined}
                  >
                    <Icon size={20} aria-hidden="true" />
                    <span className="mobile-nav__link-label">{link.label}</span>
                    {active && <span className="mobile-nav__mark" aria-hidden="true" />}
                  </Link>
                );
              })}
            </nav>
            <p className="mobile-nav__hint">{brand.tagline}</p>
          </div>
        </div>,
        document.body,
      )}
    </nav>
  );
}