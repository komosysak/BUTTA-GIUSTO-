import type { WasteItem } from '../types';
import { WASTE_ICONS, getWasteIconName } from '../core/wasteIcons';
import { Recycle } from 'lucide-react';

interface WasteIconProps {
  item: Pick<WasteItem, 'name' | 'id' | 'destination'>;
  size?: number;
  strokeWidth?: number;
}

export function WasteIcon({ item, size = 28, strokeWidth = 1.8 }: WasteIconProps) {
  const name = getWasteIconName(item);
  const Icon = WASTE_ICONS[name] ?? Recycle;
  return <Icon size={size} strokeWidth={strokeWidth} aria-hidden="true" />;
}

