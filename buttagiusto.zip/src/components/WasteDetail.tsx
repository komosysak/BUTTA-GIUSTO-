import { useEffect, useRef, useCallback } from 'react';
import { X, Volume2, VolumeX, ArrowRight } from 'lucide-react';
import type { WasteItem } from '../types';
import { useSpeech } from '../hooks/useSpeech';
import { WasteIcon } from './WasteIcon';
import './WasteDetail.css';

interface WasteDetailProps {
  item: WasteItem | null;
  onClose: () => void;
}

const DEST_LABELS: Record<string, string> = {
  yellow: 'Multipak (sacco giallo)',
  red: 'Ecuosacco (sacco rosso)',
  blue: 'Carta e cartone',
  brown: 'Umido',
  verde: 'Verde / Scarti vegetali',
  vetro: 'Vetro',
  grey: 'Piattaforma ecologica',
};

export function WasteDetail({ item, onClose }: WasteDetailProps) {
  const { speaking, speakItem, stop } = useSpeech();
  const dialogRef = useRef<HTMLDialogElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (item) {
      dialog.showModal();
      closeButtonRef.current?.focus();
    } else {
      dialog.close();
    }
  }, [item]);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const handleClose = () => onClose();
    dialog.addEventListener('close', handleClose);
    return () => dialog.removeEventListener('close', handleClose);
  }, [onClose]);

  useEffect(() => {
    return () => stop();
  }, [item, stop]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      stop();
      onClose();
    }
  }, [stop, onClose]);

  if (!item) return null;

  return (
    <dialog
      ref={dialogRef}
      className="waste-detail"
      onKeyDown={handleKeyDown}
      aria-label={`Dettaglio: ${item.name}`}
      aria-modal="true"
    >
      <div className="waste-detail__backdrop" onClick={onClose} aria-hidden="true" />
      <div className="waste-detail__panel" role="document">
        <div className="waste-detail__header">
          <h2 className="waste-detail__title">{item.name}</h2>
          <button
            ref={closeButtonRef}
            className="waste-detail__close"
            onClick={onClose}
            aria-label="Chiudi dettaglio"
            type="button"
          >
            <X size={20} />
          </button>
        </div>

        <div className={`waste-detail__hero waste-detail__hero--${item.destination}`} aria-hidden="true">
          <span className={`waste-detail__icon waste-detail__icon--${item.destination}`}>
            <WasteIcon item={item} size={56} strokeWidth={1.6} />
          </span>
        </div>

        <div className="waste-detail__body">
          <p className="waste-detail__desc">{item.description}</p>

          <div className="waste-detail__result">
            <span className="waste-detail__result-label">Dove va?</span>
            <div className={`waste-detail__destination waste-detail__destination--${item.destination}`}>
              <span className="waste-detail__dest-icon" aria-hidden="true">●</span>
              <ArrowRight size={16} aria-hidden="true" />
              <span className="waste-detail__dest-text">{item.destinationLabel}</span>
            </div>
            <span className="waste-detail__dest-full">{DEST_LABELS[item.destination]}</span>
          </div>

          <p className="waste-detail__note">
            Secondo le regole CEM Ambiente per il tuo comune.
          </p>

          <button
            className="waste-detail__tts"
            onClick={() => speaking ? null : speakItem(item.name, item.destinationLabel)}
            disabled={speaking}
            type="button"
            aria-label={speaking ? 'Lettura in corso' : `Leggi ad alta voce: ${item.name}, ${item.destinationLabel}`}
          >
            {speaking ? <VolumeX size={18} /> : <Volume2 size={18} />}
            <span>{speaking ? 'Lettura in corso...' : 'Leggi ad alta voce'}</span>
          </button>

          {item.aliases.length > 0 && (
            <div className="waste-detail__aliases">
              <span className="waste-detail__aliases-label">Altri nomi:</span>
              <div className="waste-detail__aliases-list">
                {item.aliases.slice(0, 6).map(alias => (
                  <span key={alias} className="waste-detail__alias">{alias}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </dialog>
  );
}
