import { useRef, useEffect } from 'react';
import { Search, X, Mic, MicOff } from 'lucide-react';
import './SearchBar.css';

interface SearchBarProps {
  query: string;
  onQueryChange: (q: string) => void;
  onClear: () => void;
  resultCount: number;
  totalCount: number;
  voiceSupported: boolean;
  voiceListening: boolean;
  onVoiceStart: () => void;
  onVoiceStop: () => void;
}

export function SearchBar({
  query,
  onQueryChange,
  onClear,
  resultCount,
  totalCount,
  voiceSupported,
  voiceListening,
  onVoiceStart,
  onVoiceStop,
}: SearchBarProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === '/' && !e.ctrlKey && !e.metaKey) {
        const target = e.target as HTMLElement;
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, []);

  return (
    <div className="search-bar" role="search" aria-label="Cerca rifiuti">
      <div className="search-bar__input-wrap">
        <Search className="search-bar__icon" size={18} aria-hidden="true" />
        <input
          ref={inputRef}
          type="search"
          className="search-bar__input"
          value={query}
          onChange={e => onQueryChange(e.target.value)}
          placeholder="Cerca un rifiuto, ad esempio: penna..."
          aria-label="Cerca un rifiuto"
          autoComplete="off"
          spellCheck={false}
        />
        {query && (
          <button
            className="search-bar__clear"
            onClick={onClear}
            aria-label="Cancella ricerca"
            type="button"
          >
            <X size={16} />
          </button>
        )}
        {voiceSupported && (
          <button
            className={`search-bar__voice ${voiceListening ? 'search-bar__voice--active' : ''}`}
            onClick={voiceListening ? onVoiceStop : onVoiceStart}
            aria-label={voiceListening ? 'Ferma ricerca vocale' : 'Avvia ricerca vocale'}
            type="button"
          >
            {voiceListening ? <MicOff size={18} /> : <Mic size={18} />}
          </button>
        )}
      </div>
      <div className="search-bar__meta" aria-live="polite" aria-atomic="true">
        {query ? (
          <span>{resultCount} {resultCount === 1 ? 'risultato' : 'risultati'}</span>
        ) : (
          <span>{totalCount} oggetti nel catalogo</span>
        )}
      </div>
    </div>
  );
}
