import { useEffect, useRef } from 'react';
import { X, Sun, Moon, Monitor, Type, Eye, MousePointer2, Zap } from 'lucide-react';
import type { ThemeMode, AccessibilitySettings } from '../types';
import './AccessibilityPanel.css';

interface AccessibilityPanelProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  onThemeChange: (m: ThemeMode) => void;
  settings: AccessibilitySettings;
  onSettingChange: <K extends keyof AccessibilitySettings>(key: K, value: AccessibilitySettings[K]) => void;
  onReset: () => void;
}

export function AccessibilityPanel({
  isOpen,
  onClose,
  theme,
  onThemeChange,
  settings,
  onSettingChange,
  onReset,
}: AccessibilityPanelProps) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (isOpen) {
      closeButtonRef.current?.focus();
      const handleEsc = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      document.addEventListener('keydown', handleEsc);
      return () => document.removeEventListener('keydown', handleEsc);
    }
  }, [isOpen, onClose]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="a11y-overlay" role="dialog" aria-label="Pannello accessibilità" aria-modal="true">
      <div className="a11y-overlay__backdrop" onClick={onClose} aria-hidden="true" />
      <div className="a11y-panel" ref={panelRef}>
        <div className="a11y-panel__header">
          <h2 className="a11y-panel__title">Accessibilità</h2>
          <button
            ref={closeButtonRef}
            className="a11y-panel__close"
            onClick={onClose}
            aria-label="Chiudi pannello"
            type="button"
          >
            <X size={20} />
          </button>
        </div>

        <div className="a11y-panel__body">
          <div className="a11y-section">
            <h3 className="a11y-section__title">
              <Sun size={16} aria-hidden="true" />
              Tema
            </h3>
            <div className="a11y-options">
              {([
                { value: 'light' as const, label: 'Chiaro', icon: Sun },
                { value: 'dark' as const, label: 'Scuro', icon: Moon },
                { value: 'system' as const, label: 'Sistema', icon: Monitor },
              ]).map(opt => {
                const Icon = opt.icon;
                return (
                  <button
                    key={opt.value}
                    className={`a11y-option ${theme === opt.value ? 'a11y-option--active' : ''}`}
                    onClick={() => onThemeChange(opt.value)}
                    type="button"
                    aria-pressed={theme === opt.value}
                  >
                    <Icon size={16} aria-hidden="true" />
                    <span>{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="a11y-section">
            <h3 className="a11y-section__title">
              <Type size={16} aria-hidden="true" />
              Dimensione testo
            </h3>
            <div className="a11y-options">
              {([
                { value: 'normal' as const, label: 'Normale' },
                { value: 'large' as const, label: 'Grande' },
                { value: 'x-large' as const, label: 'Molto grande' },
              ]).map(opt => (
                <button
                  key={opt.value}
                  className={`a11y-option ${settings.textSize === opt.value ? 'a11y-option--active' : ''}`}
                  onClick={() => onSettingChange('textSize', opt.value)}
                  type="button"
                  aria-pressed={settings.textSize === opt.value}
                >
                  <span>{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="a11y-section">
            <h3 className="a11y-section__title">
              <Eye size={16} aria-hidden="true" />
              Contrasto elevato
            </h3>
            <button
              className={`a11y-toggle ${settings.highContrast ? 'a11y-toggle--active' : ''}`}
              onClick={() => onSettingChange('highContrast', !settings.highContrast)}
              type="button"
              role="switch"
              aria-checked={settings.highContrast}
            >
              <span className="a11y-toggle__track">
                <span className="a11y-toggle__thumb" />
              </span>
            </button>
          </div>

          <div className="a11y-section">
            <h3 className="a11y-section__title">
              <Zap size={16} aria-hidden="true" />
              Riduci animazioni
            </h3>
            <button
              className={`a11y-toggle ${settings.reducedMotion ? 'a11y-toggle--active' : ''}`}
              onClick={() => onSettingChange('reducedMotion', !settings.reducedMotion)}
              type="button"
              role="switch"
              aria-checked={settings.reducedMotion}
            >
              <span className="a11y-toggle__track">
                <span className="a11y-toggle__thumb" />
              </span>
            </button>
          </div>

          <div className="a11y-section">
            <h3 className="a11y-section__title">
              <MousePointer2 size={16} aria-hidden="true" />
              Evidenzia focus
            </h3>
            <button
              className={`a11y-toggle ${settings.focusHighlight ? 'a11y-toggle--active' : ''}`}
              onClick={() => onSettingChange('focusHighlight', !settings.focusHighlight)}
              type="button"
              role="switch"
              aria-checked={settings.focusHighlight}
            >
              <span className="a11y-toggle__track">
                <span className="a11y-toggle__thumb" />
              </span>
            </button>
          </div>
        </div>

        <div className="a11y-panel__footer">
          <button className="a11y-reset" onClick={onReset} type="button">
            Ripristina impostazioni predefinite
          </button>
        </div>
      </div>
    </div>
  );
}
