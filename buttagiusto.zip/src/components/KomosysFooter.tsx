import { useRef, useEffect, useCallback, useState } from 'react';
import { brand } from '../config/brand';
import './KomosysFooter.css';

export function KomosysFooter() {
  const textRef = useRef<HTMLDivElement>(null);
  const [isReducedMotion, setIsReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setIsReducedMotion(mq.matches);
    const saved = document.documentElement.getAttribute('data-reduced-motion');
    if (saved === 'true') setIsReducedMotion(true);
    const handler = (e: MediaQueryListEvent) => setIsReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (isReducedMotion || !textRef.current) return;
    const rect = textRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    textRef.current.style.setProperty('--mx', `${x}%`);
    textRef.current.style.setProperty('--my', `${y}%`);
  }, [isReducedMotion]);

  const handleMouseLeave = useCallback(() => {
    if (textRef.current) {
      textRef.current.style.setProperty('--mx', '50%');
      textRef.current.style.setProperty('--my', '50%');
    }
  }, []);

  return (
    <section className="komosys" aria-label="KOMOSYS">
      <div className="komosys__inner">
        <div
          ref={textRef}
          className={`komosys__text ${isReducedMotion ? 'komosys__text--static' : ''}`}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          aria-hidden="true"
        >
          <span className="komosys__desktop">KOMOSYS</span>
          <span className="komosys__mobile">KOMO</span>
        </div>
        <p className="komosys__tagline">{brand.tagline}</p>
      </div>
    </section>
  );
}
