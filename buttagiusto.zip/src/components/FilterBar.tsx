import './FilterBar.css';

type FilterType = 'all' | 'yellow' | 'red' | 'blue' | 'brown' | 'verde' | 'vetro' | 'grey';

interface FilterBarProps {
  filter: FilterType;
  onFilterChange: (f: FilterType) => void;
}

const filters: { value: FilterType; label: string; icon: string }[] = [
  { value: 'all', label: 'Tutti', icon: '' },
  { value: 'yellow', label: 'Multipak', icon: '🟡' },
  { value: 'red', label: 'Ecuosacco', icon: '🔴' },
  { value: 'blue', label: 'Carta', icon: '🔵' },
  { value: 'brown', label: 'Umido', icon: '🟤' },
  { value: 'verde', label: 'Verde', icon: '🟢' },
  { value: 'vetro', label: 'Vetro', icon: '🪟' },
  { value: 'grey', label: 'Piattaforma', icon: '🏭' },
];

export function FilterBar({ filter, onFilterChange }: FilterBarProps) {
  return (
    <div className="filter-bar" role="radiogroup" aria-label="Filtra per tipo di raccolta">
      {filters.map(f => (
        <button
          key={f.value}
          className={`filter-bar__btn filter-bar__btn--${f.value} ${filter === f.value ? 'filter-bar__btn--active' : ''}`}
          onClick={() => onFilterChange(f.value)}
          role="radio"
          aria-checked={filter === f.value}
          type="button"
        >
          {f.value !== 'all' && <span className={`filter-bar__dot filter-bar__dot--${f.value}`} aria-hidden="true" />}
          {f.label}
        </button>
      ))}
    </div>
  );
}
