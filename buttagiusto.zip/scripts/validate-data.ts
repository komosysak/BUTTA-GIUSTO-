import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const ROOT = join(__dirname, '..');
const DATA_PATH = join(ROOT, 'src', 'data', 'waste-items.json');
const REPORT_DIR = join(ROOT, 'reports');
const REPORT_HTML_PATH = join(REPORT_DIR, 'image-report.html');

interface ImageInfo {
  url: string;
  thumbnailUrl?: string;
  source: string;
  sourceUrl?: string;
  author?: string;
  license?: string;
  licenseUrl?: string;
  confidence?: number;
  status: string;
  width?: number;
  height?: number;
}

interface WasteItem {
  id: string;
  name: string;
  destination: string;
  destinationLabel: string;
  description: string;
  aliases: string[];
  keywords: string[];
  category: string;
  municipality: string;
  imageSearchTerms?: string[];
  image?: ImageInfo;
}

const VALID_DESTINATIONS = ['red', 'yellow', 'blue', 'brown', 'verde', 'vetro', 'grey'];

function validateUrl(url: string): boolean {
  if (!url) return true;
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function main() {
  console.log('BUTTAGIUSTO DATA VALIDATION\n');

  const items: WasteItem[] = JSON.parse(readFileSync(DATA_PATH, 'utf-8'));
  const errors: string[] = [];
  const warnings: string[] = [];
  const ids = new Set<string>();
  const aliases = new Map<string, string>();

  let validIds = 0;
  let validDestinations = 0;
  let validAliases = 0;
  let validImageUrls = 0;
  let validImageMetadata = 0;

  let imageApproved = 0;
  let imageReview = 0;
  let imageMissing = 0;

  for (const item of items) {
    if (!item.id) {
      errors.push(`Record without ID`);
      continue;
    }
    if (ids.has(item.id)) {
      errors.push(`Duplicate ID: ${item.id}`);
    }
    ids.add(item.id);
    validIds++;

    if (!item.name) {
      errors.push(`Record without name: ${item.id}`);
    }

    if (!item.destination) {
      errors.push(`Record without destination: ${item.id}`);
    } else if (!VALID_DESTINATIONS.includes(item.destination)) {
      errors.push(`Invalid destination for ${item.id}: ${item.destination}`);
    } else {
      validDestinations++;
    }

    if (!item.aliases || item.aliases.length === 0) {
      warnings.push(`Record without aliases: ${item.id}`);
    } else {
      validAliases++;
      for (const alias of item.aliases) {
        const key = alias.toLowerCase().trim();
        if (aliases.has(key)) {
          warnings.push(`Duplicate alias "${alias}": used by ${aliases.get(key)} and ${item.id}`);
        }
        aliases.set(key, item.id);
      }
    }

    if (item.image) {
      if (item.image.url && !validateUrl(item.image.url)) {
        errors.push(`Invalid image URL for ${item.id}: ${item.image.url}`);
      } else if (item.image.url) {
        validImageUrls++;
      }

      if (item.image.source && item.image.status) {
        validImageMetadata++;
      }

      switch (item.image.status) {
        case 'approved':
          imageApproved++;
          break;
        case 'review':
          imageReview++;
          break;
        case 'missing':
          imageMissing++;
          break;
        default:
          warnings.push(`Unknown image status for ${item.id}: ${item.image.status}`);
      }
    } else {
      imageMissing++;
    }
  }

  console.log(`✓ Waste items: ${items.length}`);
  console.log(`✓ IDs valid: ${validIds}`);
  console.log(`✓ Destinations valid: ${validDestinations}`);
  console.log(`✓ Aliases valid: ${validAliases}`);
  console.log(`✓ Image URLs valid format: ${validImageUrls}`);
  console.log(`✓ Image metadata valid: ${validImageMetadata}`);

  console.log(`\nIMAGE STATUS`);
  console.log(`✓ Approved: ${imageApproved}`);
  console.log(`⚠ Review: ${imageReview}`);
  console.log(`✗ Missing: ${imageMissing}`);

  if (errors.length > 0) {
    console.log(`\n❌ Errors (${errors.length}):`);
    errors.forEach(e => console.log(`  - ${e}`));
  }

  if (warnings.length > 0) {
    console.log(`\n⚠️  Warnings (${warnings.length}):`);
    warnings.slice(0, 20).forEach(w => console.log(`  - ${w}`));
    if (warnings.length > 20) {
      console.log(`  ... and ${warnings.length - 20} more warnings`);
    }
  }

  if (errors.length === 0 && warnings.length === 0) {
    console.log(`\n✅ No issues found.`);
  }

  if (existsSync(REPORT_HTML_PATH)) {
    console.log(`\n📋 Image report available at: ${REPORT_HTML_PATH}`);
  }

  process.exit(errors.length > 0 ? 1 : 0);
}

main();
