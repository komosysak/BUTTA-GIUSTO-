/**
 * Verify that every waste item resolves to a specific (non-fallback) icon
 * via the deterministic keyword rules in WasteIcon.tsx.
 *
 * Usage: npx tsx scripts/check-icons.ts
 */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { resolveWasteIcon } from '../src/core/wasteIcons';
import type { Destination } from '../src/types';

const raw = readFileSync(resolve('src/data/waste-items.json'), 'utf-8');
const data = JSON.parse(raw) as Array<Record<string, unknown>>;
const items = Array.isArray(data) ? data : (data as { items: Array<Record<string, unknown>> }).items;

let fallbackCount = 0;
const byIcon = new Map<string, number>();

for (const item of items) {
  const destination = item.destination as Destination;
  const { icon, matched } = resolveWasteIcon({
    id: String(item.id),
    name: String(item.name),
    destination,
  });
  byIcon.set(icon, (byIcon.get(icon) ?? 0) + 1);
  if (!matched) {
    fallbackCount += 1;
    console.log(`FALLBACK: ${String(item.name).padEnd(50)} -> ${icon}`);
  }
}

console.log(`\nTotal items: ${items.length}`);
console.log(`Items using a fallback icon: ${fallbackCount}`);
console.log(`Distinct icons used: ${byIcon.size}`);
console.log('\nIcon usage:');
for (const [icon, count] of [...byIcon.entries()].sort((a, b) => b[1] - a[1])) {
  console.log(`  ${String(icon).padEnd(20)} ${count}`);
}

if (fallbackCount > 0) {
  console.error('\n❌ Some items are missing a specific icon — add keyword rules.');
  process.exit(1);
}
console.log('\n✅ All items have a specific icon.');