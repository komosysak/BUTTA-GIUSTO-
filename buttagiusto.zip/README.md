# ButtaGiusto

Servizio web italiano che aiuta le persone a capire dove buttare correttamente un determinato rifiuto.

**"Non devi sapere come funziona la raccolta differenziata. Devi soltanto sapere che cosa hai in mano."**

## Stack

- React 19 + TypeScript
- Vite
- React Router
- Fuse.js (ricerca fuzzy)
- Lucide Icons
- CSS custom properties (design tokens)

## Installazione

```bash
git clone https://github.com/komosysak/BUTTA-GIUSTO-.git
cd buttagiusto
npm install
```

## Sviluppo

```bash
npm run dev
```

## Build

```bash
npm run build
```

La directory `dist/` generata può essere pubblicata direttamente su Netlify.

## Deploy su Netlify

1. Esegui `npm run build`
2. Carica la cartella `dist/` su Netlify
3. Oppure collega il repository GitHub per deploy automatico

Il file `netlify.toml` è già configurato con il redirect SPA.

## Struttura del progetto

```
src/
├── config/          # Brand e configurazioni
├── core/            # Motore deterministico
│   ├── classification/
│   ├── normalization/
│   └── search/
├── components/      # Componenti UI
├── data/            # Dataset e configurazioni comuni
│   ├── municipalities/
│   └── waste-items.json
├── hooks/           # Custom hooks
├── pages/           # Pagine dell'applicazione
├── styles/          # Design tokens e stili globali
├── types/           # Type definitions
└── utils/           # Utility functions
```

## Dataset

Il dataset `src/data/waste-items.json` contiene tutti gli oggetti con le loro classificazioni.

### Formato di un record

```json
{
  "id": "penne-biro",
  "name": "Penne biro",
  "destination": "red",
  "destinationLabel": "Sacco rosso",
  "description": "Comune penna a sfera utilizzata per scrivere.",
  "aliases": ["penna", "penne", "biro", "penna a sfera"],
  "keywords": ["scrittura", "ufficio", "scuola"],
  "category": "cancelleria",
  "municipality": "default"
}
```

### Come aggiungere un rifiuto

1. Apri `src/data/waste-items.json`
2. Aggiungi un nuovo record seguendo il formato sopra
3. Assegna un `id` univoco
4. Imposta `destination` su una delle categorie: `"yellow"` (Multipak), `"red"` (Ecuosacco), `"blue"` (Carta), `"brown"` (Umido), `"verde"` (Scarti vegetali), `"vetro"` (Vetro), `"grey"` (Piattaforma ecologica)
5. Aggiungi alias utili per la ricerca
6. Esegui `npm run build` per verificare

### Come creare un nuovo comune

1. Crea un nuovo file in `src/data/municipalities/`
2. Segui il formato di `default.json`
3. Modifica il dataset per associare gli oggetti al nuovo comune
4. Il frontend non richiede modifiche

## Accessibilità

L'applicazione è progettata per essere WCAG 2.2 AA conforme:

- HTML semantico e landmarks
- Navigazione completa da tastiera
- Contrasto adeguato (4.5:1 minimo)
- Focus states visibili
- Text-to-Speech nativo
- Ricerca vocale (dove supportata)
- Pannello accessibilità con:
  - Tema chiaro/scuro/sistema
  - Dimensione testo regolabile
  - Contrasto elevato
  - Riduzione animazioni
  - Evidenziazione focus

## Dark mode

Supporta tre modalità:
- **Chiaro**: tema predefinito
- **Scuro**: palette ottimizzata per l'oscurità
- **Sistema**: segue le preferenze del sistema operativo

Le preferenze vengono salvate in localStorage.

## Roadmap

### V1 (attuale)
- Core deterministico
- Ricerca fuzzy con ranking
- Catalogo visuale
- Accessibilità WCAG 2.2 AA
- Dark mode
- Text-to-Speech
- Ricerca vocale

### V1.1
- Supporto multi-comune
- Dataset remoto da GitHub

### V1.2
- Statistiche di utilizzo (anonymous)
- PWA completa con service worker

### V2
- Riconoscimento vocale migliorato
- Suggerimenti intelligenti

### V3
- Computer vision (foto → classificazione)

### V4
- Assistente AI opzionale (solo come interprete, mai come source of truth)

## Licenza

MIT

## Creato da

Sito web open source creato da **KOMOSYS Dev**
